package com.example.watermarkapp;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private ImageView imageView;
    private Button btnPick, btnCapture, btnApplyWatermark, btnSave;
    private EditText edtWatermarkText, edtFolder;

    private Bitmap selectedBitmap;
    private Uri photoUri;
    private File photoFile;

    private ActivityResultLauncher<Intent> pickImageLauncher;
    private ActivityResultLauncher<Uri> takePictureLauncher; // TakePicture contract
    private ActivityResultLauncher<String[]> requestPermissionsLauncher;

    private static final String TAG = "WatermarkApp";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        btnPick = findViewById(R.id.btnPick);
        btnCapture = findViewById(R.id.btnCapture);
        btnApplyWatermark = findViewById(R.id.btnApplyWatermark);
        btnSave = findViewById(R.id.btnSave);
        edtWatermarkText = findViewById(R.id.edtWatermarkText);
        edtFolder = findViewById(R.id.edtFolder);

        // 1) Register pick-from-gallery launcher
        pickImageLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                            Uri uri = result.getData().getData();
                            if (uri != null) {
                                try (InputStream is = getContentResolver().openInputStream(uri)) {
                                    selectedBitmap = BitmapFactory.decodeStream(is);
                                    imageView.setImageBitmap(selectedBitmap);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                    Toast.makeText(MainActivity.this, "Failed to load image", Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                    }
                }
        );

        // 2) Register camera take-picture launcher (saves to provided Uri)
        takePictureLauncher = registerForActivityResult(
                new ActivityResultContracts.TakePicture(),
                new ActivityResultCallback<Boolean>() {
                    @Override
                    public void onActivityResult(Boolean result) {
                        if (result) {
                            // photoUri contains the image saved by camera
                            try (InputStream is = getContentResolver().openInputStream(photoUri)) {
                                selectedBitmap = BitmapFactory.decodeStream(is);
                                imageView.setImageBitmap(selectedBitmap);
                            } catch (IOException e) {
                                e.printStackTrace();
                                Toast.makeText(MainActivity.this, "Failed to load captured image", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(MainActivity.this, "Camera cancelled", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        );

        // 3) Register permissions launcher
        requestPermissionsLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestMultiplePermissions(),
                new ActivityResultCallback<Map<String, Boolean>>() {
                    @Override
                    public void onActivityResult(Map<String, Boolean> result) {
                        boolean cameraGranted = Boolean.TRUE.equals(result.get(Manifest.permission.CAMERA));
                        boolean writeGranted = Boolean.TRUE.equals(result.get(Manifest.permission.WRITE_EXTERNAL_STORAGE));
                        if (cameraGranted) {
                            openCamera();
                        } else {
                            Toast.makeText(MainActivity.this, "Camera permission required", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        );

        btnPick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });

        btnCapture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // request camera permission (and WRITE for older devices)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    // WRITE_EXTERNAL_STORAGE not needed for scoped-storage devices when saving via MediaStore
                    requestPermissionsLauncher.launch(new String[]{Manifest.permission.CAMERA});
                } else {
                    requestPermissionsLauncher.launch(new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE});
                }
            }
        });

        btnApplyWatermark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedBitmap == null) {
                    Toast.makeText(MainActivity.this, "Pick or capture an image first", Toast.LENGTH_SHORT).show();
                    return;
                }
                String wmText = edtWatermarkText.getText().toString();
                if (wmText.trim().isEmpty()) wmText = "© MyApp";
                selectedBitmap = addTextWatermark(selectedBitmap, wmText);
                imageView.setImageBitmap(selectedBitmap);
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedBitmap == null) {
                    Toast.makeText(MainActivity.this, "Nothing to save", Toast.LENGTH_SHORT).show();
                    return;
                }
                String folder = edtFolder.getText().toString().trim();
                if (folder.isEmpty()) folder = "Watermarked";
                String filename = "WM_" + System.currentTimeMillis() + ".jpg";
                try {
                    saveBitmapToGallery(selectedBitmap, folder, filename);
                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(MainActivity.this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        pickImageLauncher.launch(intent);
    }

    private void openCamera() {
        try {
            photoFile = createImageFile();
            if (photoFile != null) {
                photoUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", photoFile);
                takePictureLauncher.launch(photoUri);
            }
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Could not create file for camera", Toast.LENGTH_SHORT).show();
        }
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = "IMG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        if (storageDir != null && !storageDir.exists()) storageDir.mkdirs();
        File image = File.createTempFile(imageFileName, ".jpg", storageDir);
        return image;
    }

    private Bitmap addTextWatermark(Bitmap src, String watermarkText) {
        int w = src.getWidth();
        int h = src.getHeight();

        Bitmap result = src.copy(Bitmap.Config.ARGB_8888, true);
        Canvas canvas = new Canvas(result);

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.WHITE);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(Math.max(24, w / 20));
        paint.setAlpha(230);
        paint.setShadowLayer(4f, 2f, 2f, Color.BLACK);

        Rect bounds = new Rect();
        paint.getTextBounds(watermarkText, 0, watermarkText.length(), bounds);

        int padding = 20;
        int x = w - bounds.width() - padding;
        int y = h - padding;

        // draw text
        canvas.drawText(watermarkText, x, y, paint);
        return result;
    }

    private void saveBitmapToGallery(Bitmap bitmap, String folderName, String fileName) throws IOException {
        OutputStream fos = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
            values.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + folderName);
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);

            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("Failed to create new MediaStore record.");

            try {
                fos = getContentResolver().openOutputStream(uri);
                if (fos == null) throw new IOException("Failed to get output stream.");
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, fos);
            } finally {
                if (fos != null) fos.close();
                values.clear();
                values.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(uri, values, null, null);
                Toast.makeText(this, "Saved to Pictures/" + folderName, Toast.LENGTH_SHORT).show();
            }

        } else {
            // Fallback for older devices
            String imagesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString() + File.separator + folderName;
            File dir = new File(imagesDir);
            if (!dir.exists()) dir.mkdirs();
            File image = new File(dir, fileName);
            try {
                fos = new FileOutputStream(image);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, fos);
            } finally {
                if (fos != null) fos.close();
                // Make available in gallery
                MediaStore.Images.Media.insertImage(getContentResolver(), image.getAbsolutePath(), image.getName(), null);
                Toast.makeText(this, "Saved to " + image.getAbsolutePath(), Toast.LENGTH_SHORT).show();
            }
        }
    }

}